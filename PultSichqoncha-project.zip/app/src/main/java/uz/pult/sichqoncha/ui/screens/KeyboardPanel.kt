package uz.pult.sichqoncha.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.pult.engine.Keys
import uz.pult.engine.Modifiers
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.ui.KeyAction
import uz.pult.sichqoncha.ui.MainViewModel

private val SPECIAL_KEYS = listOf(
    KeyAction(R.string.key_enter, 0, Keys.ENTER),
    KeyAction(R.string.key_backspace, 0, Keys.BACKSPACE),
    KeyAction(R.string.key_tab, 0, Keys.TAB),
    KeyAction(R.string.key_esc, 0, Keys.ESCAPE),
    KeyAction(R.string.key_delete, 0, Keys.DELETE),
    KeyAction(R.string.key_up, 0, Keys.UP),
    KeyAction(R.string.key_home, 0, Keys.HOME),
    KeyAction(R.string.key_end, 0, Keys.END),
    KeyAction(R.string.key_left, 0, Keys.LEFT),
    KeyAction(R.string.key_down, 0, Keys.DOWN),
    KeyAction(R.string.key_right, 0, Keys.RIGHT),
    KeyAction(R.string.key_pgup, 0, Keys.PAGE_UP),
    KeyAction(R.string.key_pgdn, 0, Keys.PAGE_DOWN),
    KeyAction(R.string.key_win, Modifiers.GUI, Keys.NONE),
    KeyAction(R.string.key_alttab, Modifiers.ALT, Keys.TAB),
    KeyAction(R.string.key_selectall, Modifiers.CTRL, Keys.A),
    KeyAction(R.string.key_copy, Modifiers.CTRL, Keys.C),
    KeyAction(R.string.key_cut, Modifiers.CTRL, Keys.X),
    KeyAction(R.string.key_paste, Modifiers.CTRL, Keys.V),
    KeyAction(R.string.key_undo, Modifiers.CTRL, Keys.Z),
    KeyAction(R.string.key_save, Modifiers.CTRL, Keys.S)
)

@Composable
fun KeyboardPanel(vm: MainViewModel, modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf("") }
    val skipped by vm.skippedChars.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { newValue ->
                vm.liveEdit(text, newValue)
                text = newValue
            },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.keyboard_hint)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.VisiblePassword)
        )
        OutlinedButton(
            onClick = {
                text = ""
                vm.clearSkipped()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.keyboard_clear))
        }
        if (skipped > 0) {
            Text(
                text = stringResource(R.string.keyboard_skipped, skipped),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
        KeyActionGrid(actions = SPECIAL_KEYS, vm = vm, columns = 4)
    }
}
