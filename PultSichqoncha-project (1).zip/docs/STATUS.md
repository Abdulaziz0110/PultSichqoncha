# PultSichqoncha - STATUS

Telefon Bluetooth HID qurilma sifatida kompyuterga ulanadi: sichqoncha (touchpad), taqdimot pulti, klaviatura, media tugmalari.
applicationId: uz.pult.sichqoncha, minSdk 28 (BluetoothHidDevice API 28 dan boshlanadi).

## VERIFIED
- :core:engine kotlinc 2.1.0 bilan kompilyatsiya qilindi, 49 ta JUnit testi o'tdi (HID descriptor tuzilishi va hisobot o'lchamlari, hisobot tuzuvchilar, klavisha xaritasi, matn farqi, touchpad: harakat, tezlanish, tap, o'ng/o'rta klik, scroll, sudrash).
- Statik skript: ichki importlar, barcha R.string kalitlari (yetishmayotgani yo'q), format argumentlari soni va turi, opt-in'lar, taqiqlangan konstruksiyalar (!!, runBlocking, reversed va h.k.), BOM/ko'rinmas belgi yo'q.
- android-build.yml: YAML to'g'ri o'qiladi, faqat ASCII.

## IMPLEMENTED-UNVERIFIED
- :app moduli (Compose, Navigation, ViewModel, SettingsStore, HidController) Gradle bilan kompilyatsiya QILINMAGAN: bu muhitda Google Maven'ga kirish yo'q. Birinchi GitHub Actions ishga tushirishida kompilyatsiya xatosi chiqsa, reports artifact'ini yuboring.
- Haqiqiy Bluetooth ulanishi (registerApp, juftlash, sendReport) real telefon va kompyuterda sinalmagan.
- Workflow (ZIP sinxron ochish, kalit yaratish va commit, APK, test, lint) GitHub'da ishga tushirilmagan.

## NOT-IMPLEMENTED
- Wi-Fi rejimi (kompyuterda server kerak bo'lardi).
- Room, WorkManager, Glance: ilovaga kerak bo'lmagani uchun ishlatilmadi (sozlamalar SharedPreferences'da).
- Lotin harflari va oddiy belgilardan boshqa matn (kirill, o' g' va h.k.): HID klaviaturasi faqat AQSh tartibida ishlaydi, bunday belgilar yuborilmaydi va ekranda sanaladi.
- Fon xizmati: ilova to'liq yopilsa ulanish uziladi.
- gradle-wrapper: workflow Gradle 8.11.1 ni o'zi o'rnatadi, gradlew jar fayli yo'q.
- Ekrandagi lazer ko'rsatkich (faqat Ctrl+L tugmasi yuboriladi).
- Ba'zi telefonlarda (ishlab chiqaruvchi HID profilini o'chirgan) rejim ishlamaydi; ilova buni "qo'llamaydi" holati bilan ko'rsatadi.

## Ishlatish
1. PultSichqoncha-project.zip va android-build.yml (.github/workflows/ ichida) ni GitHub repoga yuklang.
2. Actions > Android build > Run workflow. Birinchi ishga tushirishda signing/ papkasida kalit yaratilib commit qilinadi.
3. Artifact "apk" ni yuklab o'rnating.
