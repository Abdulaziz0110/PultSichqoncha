package uz.pult.sichqoncha.ui.screens

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.hid.HidStatus
import uz.pult.sichqoncha.hid.HidUiState
import uz.pult.sichqoncha.hid.PairedDevice
import uz.pult.sichqoncha.ui.MainViewModel
import uz.pult.sichqoncha.ui.startActivitySafely

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicesScreen(
    vm: MainViewModel,
    onOpenControl: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val hid by vm.hidState.collectAsStateWithLifecycle()
    val paired by vm.paired.collectAsStateWithLifecycle()
    var previous by remember { mutableStateOf(hid.status) }
    var asked by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> vm.startHid() }
    val enableLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> vm.startHid() }

    LifecycleResumeEffect(Unit) {
        vm.startHid()
        onPauseOrDispose { }
    }

    LaunchedEffect(hid.status) {
        if (previous != HidStatus.CONNECTED && hid.status == HidStatus.CONNECTED) {
            onOpenControl()
        }
        previous = hid.status
        if (hid.status == HidStatus.NO_PERMISSION && !asked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            asked = true
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }

    val onGrant: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }
    val onAppSettings: () -> Unit = {
        startActivitySafely(
            context,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
        )
    }
    val onEnableBluetooth: () -> Unit = {
        enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
    }
    val onBluetoothSettings: () -> Unit = {
        startActivitySafely(context, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }
    val onStart: () -> Unit = { vm.startHid() }
    val onRefresh: () -> Unit = { vm.refreshPaired() }
    val onDisconnect: () -> Unit = { vm.disconnect() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.devices_title)) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = stringResource(R.string.cd_settings)
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "status") {
                StatusCard(state = hid)
            }
            item(key = "actions") {
                ActionsBlock(
                    status = hid.status,
                    onGrant = onGrant,
                    onAppSettings = onAppSettings,
                    onEnableBluetooth = onEnableBluetooth,
                    onStart = onStart,
                    onBluetoothSettings = onBluetoothSettings,
                    onRefresh = onRefresh,
                    onOpenControl = onOpenControl,
                    onDisconnect = onDisconnect
                )
            }
            if (hid.status == HidStatus.READY || hid.status == HidStatus.CONNECTING || hid.status == HidStatus.CONNECTED) {
                item(key = "paired_title") {
                    SectionTitle(R.string.paired_title)
                }
                if (paired.isEmpty()) {
                    item(key = "paired_empty") {
                        InfoText(R.string.paired_empty)
                    }
                } else {
                    items(paired, key = { device -> device.address }) { device ->
                        DeviceRow(
                            device = device,
                            enabled = hid.status == HidStatus.READY,
                            onClick = { vm.connect(device.address) }
                        )
                    }
                }
            }
            item(key = "howto") {
                HowToCard()
            }
        }
    }
}

@Composable
private fun StatusCard(state: HidUiState) {
    val text = when (state.status) {
        HidStatus.UNSUPPORTED -> stringResource(R.string.status_unsupported)
        HidStatus.NO_PERMISSION -> stringResource(R.string.status_no_permission)
        HidStatus.BLUETOOTH_OFF -> stringResource(R.string.status_bt_off)
        HidStatus.STOPPED -> stringResource(R.string.status_stopped)
        HidStatus.PREPARING -> stringResource(R.string.status_preparing)
        HidStatus.READY -> stringResource(R.string.status_ready)
        HidStatus.CONNECTING -> stringResource(R.string.status_connecting)
        HidStatus.CONNECTED -> stringResource(R.string.status_connected, state.deviceName ?: "")
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = text, style = MaterialTheme.typography.titleMedium)
            if (state.status == HidStatus.PREPARING || state.status == HidStatus.CONNECTING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun ActionsBlock(
    status: HidStatus,
    onGrant: () -> Unit,
    onAppSettings: () -> Unit,
    onEnableBluetooth: () -> Unit,
    onStart: () -> Unit,
    onBluetoothSettings: () -> Unit,
    onRefresh: () -> Unit,
    onOpenControl: () -> Unit,
    onDisconnect: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (status) {
            HidStatus.NO_PERMISSION -> {
                Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_grant))
                }
                TextButton(onClick = onAppSettings, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_app_settings))
                }
            }
            HidStatus.BLUETOOTH_OFF -> {
                Button(onClick = onEnableBluetooth, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_enable_bt))
                }
            }
            HidStatus.STOPPED -> {
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_start))
                }
            }
            HidStatus.READY, HidStatus.CONNECTING -> {
                OutlinedButton(onClick = onBluetoothSettings, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_bt_settings))
                }
                OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_refresh))
                }
            }
            HidStatus.CONNECTED -> {
                Button(onClick = onOpenControl, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_open_control))
                }
                OutlinedButton(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_disconnect))
                }
            }
            HidStatus.UNSUPPORTED, HidStatus.PREPARING -> Unit
        }
    }
}

@Composable
private fun SectionTitle(titleRes: Int) {
    Text(text = stringResource(titleRes), style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun InfoText(textRes: Int) {
    Text(text = stringResource(textRes), style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun DeviceRow(device: PairedDevice, enabled: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        ListItem(
            headlineContent = { Text(device.name) },
            supportingContent = { Text(device.address) },
            modifier = Modifier.clickable(enabled = enabled, onClick = onClick)
        )
    }
}

@Composable
private fun HowToCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = stringResource(R.string.howto_title),
                style = MaterialTheme.typography.titleSmall
            )
            Text(
                text = stringResource(R.string.howto_body),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
