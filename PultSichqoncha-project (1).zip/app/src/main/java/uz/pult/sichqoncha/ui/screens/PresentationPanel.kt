package uz.pult.sichqoncha.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import uz.pult.engine.ConsumerKeys
import uz.pult.engine.Keys
import uz.pult.engine.Modifiers
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.ui.KeyAction
import uz.pult.sichqoncha.ui.MainViewModel

private val PREV_SLIDE = KeyAction(R.string.present_prev, 0, Keys.LEFT)
private val NEXT_SLIDE = KeyAction(R.string.present_next, 0, Keys.RIGHT)

private val PRESENT_ACTIONS = listOf(
    KeyAction(R.string.present_start, 0, Keys.F5),
    KeyAction(R.string.present_end, 0, Keys.ESCAPE),
    KeyAction(R.string.present_black, 0, Keys.B),
    KeyAction(R.string.present_white, 0, Keys.W),
    KeyAction(R.string.present_laser, Modifiers.CTRL, Keys.L)
)

private val VOLUME_ACTIONS = listOf(
    KeyAction(R.string.media_vol_down, 0, ConsumerKeys.VOLUME_DOWN, consumer = true),
    KeyAction(R.string.media_mute, 0, ConsumerKeys.MUTE, consumer = true),
    KeyAction(R.string.media_vol_up, 0, ConsumerKeys.VOLUME_UP, consumer = true)
)

@Composable
fun PresentationPanel(vm: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { vm.sendAction(PREV_SLIDE) },
                modifier = Modifier
                    .weight(1f)
                    .height(160.dp)
            ) {
                Text(
                    text = stringResource(PREV_SLIDE.label),
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Button(
                onClick = { vm.sendAction(NEXT_SLIDE) },
                modifier = Modifier
                    .weight(1f)
                    .height(160.dp)
            ) {
                Text(
                    text = stringResource(NEXT_SLIDE.label),
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }
        KeyActionGrid(actions = PRESENT_ACTIONS, vm = vm, columns = 2)
        KeyActionGrid(actions = VOLUME_ACTIONS, vm = vm, columns = 3)
    }
}
