package uz.pult.sichqoncha.ui.screens

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import uz.pult.engine.MouseButton
import uz.pult.engine.TouchPoint
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.ui.MainViewModel

@Composable
fun TouchpadPanel(vm: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TouchSurface(
            onFrame = { points, timeMs -> vm.onTouch(points, timeMs) },
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HoldButton(
                label = stringResource(R.string.btn_left),
                onDown = { vm.buttonDown(MouseButton.LEFT) },
                onUp = { vm.buttonUp(MouseButton.LEFT) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
            HoldButton(
                label = stringResource(R.string.btn_right),
                onDown = { vm.buttonDown(MouseButton.RIGHT) },
                onUp = { vm.buttonUp(MouseButton.RIGHT) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
private fun TouchSurface(
    onFrame: (List<TouchPoint>, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentOnFrame by rememberUpdatedState(onFrame)
    val hint = stringResource(R.string.touchpad_hint)
    val hintColor = MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        modifier = modifier.pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    val active = ArrayList<TouchPoint>(event.changes.size)
                    for (change in event.changes) {
                        if (change.pressed) {
                            active.add(
                                TouchPoint(
                                    change.id.value.toInt(),
                                    change.position.x,
                                    change.position.y
                                )
                            )
                        }
                    }
                    val time = event.changes.firstOrNull()?.uptimeMillis ?: 0L
                    currentOnFrame(active, time)
                    for (change in event.changes) {
                        change.consume()
                    }
                }
            }
        },
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text = hint, color = hintColor, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun HoldButton(
    label: String,
    onDown: () -> Unit,
    onUp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentDown by rememberUpdatedState(onDown)
    val currentUp by rememberUpdatedState(onUp)
    var pressed by remember { mutableStateOf(false) }
    val background = if (pressed) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.secondaryContainer
    }
    val foreground = if (pressed) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(
        modifier = modifier.pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    currentDown()
                    try {
                        tryAwaitRelease()
                    } finally {
                        pressed = false
                        currentUp()
                    }
                }
            )
        },
        shape = RoundedCornerShape(16.dp),
        color = background
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = label, color = foreground, style = MaterialTheme.typography.titleMedium)
        }
    }
}
