package uz.pult.sichqoncha.data

import uz.pult.engine.TouchpadConfig

data class AppSettings(
    val sensitivity: Float = 1.5f,
    val scrollSpeed: Float = 1.0f,
    val acceleration: Boolean = true,
    val naturalScroll: Boolean = false,
    val tapToClick: Boolean = true,
    val keepScreenOn: Boolean = true
)

fun AppSettings.toConfig(density: Float): TouchpadConfig = TouchpadConfig(
    sensitivity = sensitivity,
    acceleration = acceleration,
    scrollSpeed = scrollSpeed,
    naturalScroll = naturalScroll,
    tapToClick = tapToClick,
    density = density
)
