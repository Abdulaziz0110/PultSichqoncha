package uz.pult.sichqoncha.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = sanitize(transform(_state.value))
        _state.value = next
        prefs.edit()
            .putFloat(KEY_SENSITIVITY, next.sensitivity)
            .putFloat(KEY_SCROLL_SPEED, next.scrollSpeed)
            .putBoolean(KEY_ACCELERATION, next.acceleration)
            .putBoolean(KEY_NATURAL, next.naturalScroll)
            .putBoolean(KEY_TAP, next.tapToClick)
            .putBoolean(KEY_KEEP_ON, next.keepScreenOn)
            .apply()
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return sanitize(
            AppSettings(
                sensitivity = prefs.getFloat(KEY_SENSITIVITY, d.sensitivity),
                scrollSpeed = prefs.getFloat(KEY_SCROLL_SPEED, d.scrollSpeed),
                acceleration = prefs.getBoolean(KEY_ACCELERATION, d.acceleration),
                naturalScroll = prefs.getBoolean(KEY_NATURAL, d.naturalScroll),
                tapToClick = prefs.getBoolean(KEY_TAP, d.tapToClick),
                keepScreenOn = prefs.getBoolean(KEY_KEEP_ON, d.keepScreenOn)
            )
        )
    }

    private fun sanitize(s: AppSettings): AppSettings = s.copy(
        sensitivity = s.sensitivity.coerceIn(MIN_SENSITIVITY, MAX_SENSITIVITY),
        scrollSpeed = s.scrollSpeed.coerceIn(MIN_SCROLL, MAX_SCROLL)
    )

    companion object {
        const val MIN_SENSITIVITY = 0.5f
        const val MAX_SENSITIVITY = 4f
        const val MIN_SCROLL = 0.5f
        const val MAX_SCROLL = 3f

        private const val PREFS_NAME = "pult_settings"
        private const val KEY_SENSITIVITY = "sensitivity"
        private const val KEY_SCROLL_SPEED = "scroll_speed"
        private const val KEY_ACCELERATION = "acceleration"
        private const val KEY_NATURAL = "natural_scroll"
        private const val KEY_TAP = "tap_to_click"
        private const val KEY_KEEP_ON = "keep_screen_on"
    }
}
