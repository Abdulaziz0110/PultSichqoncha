package uz.pult.sichqoncha.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.data.SettingsStore
import uz.pult.sichqoncha.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column {
                Text(
                    text = stringResource(R.string.settings_sensitivity, s.sensitivity),
                    style = MaterialTheme.typography.bodyLarge
                )
                Slider(
                    value = s.sensitivity,
                    onValueChange = { value -> vm.updateSettings { it.copy(sensitivity = value) } },
                    valueRange = SettingsStore.MIN_SENSITIVITY..SettingsStore.MAX_SENSITIVITY
                )
            }
            Column {
                Text(
                    text = stringResource(R.string.settings_scroll_speed, s.scrollSpeed),
                    style = MaterialTheme.typography.bodyLarge
                )
                Slider(
                    value = s.scrollSpeed,
                    onValueChange = { value -> vm.updateSettings { it.copy(scrollSpeed = value) } },
                    valueRange = SettingsStore.MIN_SCROLL..SettingsStore.MAX_SCROLL
                )
            }
            SwitchRow(
                label = stringResource(R.string.settings_accel),
                checked = s.acceleration,
                onChecked = { value -> vm.updateSettings { it.copy(acceleration = value) } }
            )
            SwitchRow(
                label = stringResource(R.string.settings_natural),
                checked = s.naturalScroll,
                onChecked = { value -> vm.updateSettings { it.copy(naturalScroll = value) } }
            )
            SwitchRow(
                label = stringResource(R.string.settings_tap),
                checked = s.tapToClick,
                onChecked = { value -> vm.updateSettings { it.copy(tapToClick = value) } }
            )
            SwitchRow(
                label = stringResource(R.string.settings_keep_on),
                checked = s.keepScreenOn,
                onChecked = { value -> vm.updateSettings { it.copy(keepScreenOn = value) } }
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.settings_limits_title),
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = stringResource(R.string.settings_limits_body),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge
        )
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
