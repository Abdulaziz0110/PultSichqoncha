package uz.pult.sichqoncha

import android.content.Context
import uz.pult.sichqoncha.data.SettingsStore
import uz.pult.sichqoncha.hid.HidController

/** Manual dependency container (no DI framework). */
class AppContainer(context: Context) {
    val settings: SettingsStore = SettingsStore(context)
    val hid: HidController = HidController(context)
}
