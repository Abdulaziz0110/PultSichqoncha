package uz.pult.sichqoncha.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.hid.HidStatus
import uz.pult.sichqoncha.ui.MainViewModel

private val TAB_TITLES = listOf(
    R.string.tab_mouse,
    R.string.tab_present,
    R.string.tab_keyboard,
    R.string.tab_media
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ControlScreen(vm: MainViewModel, onBack: () -> Unit) {
    val hid by vm.hidState.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val density = LocalDensity.current.density
    val view = LocalView.current
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(density) {
        vm.setDensity(density)
    }

    LaunchedEffect(hid.status) {
        if (hid.status != HidStatus.CONNECTED) {
            onBack()
        }
    }

    DisposableEffect(settings.keepScreenOn) {
        view.keepScreenOn = settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(hid.deviceName ?: stringResource(R.string.app_name)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                actions = {
                    TextButton(onClick = { vm.disconnect() }) {
                        Text(stringResource(R.string.btn_disconnect))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            TabRow(selectedTabIndex = tab, modifier = Modifier.fillMaxWidth()) {
                TAB_TITLES.forEachIndexed { index, titleRes ->
                    Tab(
                        selected = tab == index,
                        onClick = { tab = index },
                        text = { Text(stringResource(titleRes)) }
                    )
                }
            }
            when (tab) {
                0 -> TouchpadPanel(vm = vm, modifier = Modifier.weight(1f))
                1 -> PresentationPanel(vm = vm, modifier = Modifier.weight(1f))
                2 -> KeyboardPanel(vm = vm, modifier = Modifier.weight(1f))
                else -> MediaPanel(vm = vm, modifier = Modifier.weight(1f))
            }
        }
    }
}
