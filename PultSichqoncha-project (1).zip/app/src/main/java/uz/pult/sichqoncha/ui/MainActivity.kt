package uz.pult.sichqoncha.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import uz.pult.sichqoncha.PultApp
import uz.pult.sichqoncha.ui.screens.ControlScreen
import uz.pult.sichqoncha.ui.screens.DevicesScreen
import uz.pult.sichqoncha.ui.screens.SettingsScreen
import uz.pult.sichqoncha.ui.theme.PultTheme

object Routes {
    const val DEVICES = "devices"
    const val CONTROL = "control"
    const val SETTINGS = "settings"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PultTheme {
                AppRoot()
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val container = (context.applicationContext as PultApp).container
    val vm: MainViewModel = viewModel(factory = AppViewModelFactory(container))
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = Routes.DEVICES) {
        composable(Routes.DEVICES) {
            DevicesScreen(
                vm = vm,
                onOpenControl = { nav.navigate(Routes.CONTROL) { launchSingleTop = true } },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) { launchSingleTop = true } }
            )
        }
        composable(Routes.CONTROL) {
            ControlScreen(vm = vm, onBack = { nav.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(vm = vm, onBack = { nav.popBackStack() })
        }
    }
}
