package uz.pult.sichqoncha.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import uz.pult.engine.ConsumerKeys
import uz.pult.sichqoncha.R
import uz.pult.sichqoncha.ui.KeyAction
import uz.pult.sichqoncha.ui.MainViewModel

private val MEDIA_ACTIONS = listOf(
    KeyAction(R.string.media_prev, 0, ConsumerKeys.PREV_TRACK, consumer = true),
    KeyAction(R.string.media_play, 0, ConsumerKeys.PLAY_PAUSE, consumer = true),
    KeyAction(R.string.media_next, 0, ConsumerKeys.NEXT_TRACK, consumer = true),
    KeyAction(R.string.media_vol_down, 0, ConsumerKeys.VOLUME_DOWN, consumer = true),
    KeyAction(R.string.media_mute, 0, ConsumerKeys.MUTE, consumer = true),
    KeyAction(R.string.media_vol_up, 0, ConsumerKeys.VOLUME_UP, consumer = true)
)

@Composable
fun MediaPanel(vm: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        KeyActionGrid(actions = MEDIA_ACTIONS, vm = vm, columns = 3)
    }
}
