package uz.pult.sichqoncha.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import uz.pult.engine.KeyStroke
import uz.pult.engine.MouseButton
import uz.pult.engine.PointerAction
import uz.pult.engine.TextTyper
import uz.pult.engine.TouchPoint
import uz.pult.engine.TouchpadEngine
import uz.pult.sichqoncha.AppContainer
import uz.pult.sichqoncha.data.AppSettings
import uz.pult.sichqoncha.data.toConfig
import uz.pult.sichqoncha.hid.HidUiState
import uz.pult.sichqoncha.hid.PairedDevice

class MainViewModel(container: AppContainer) : ViewModel() {
    private val hid = container.hid
    private val settingsStore = container.settings

    val hidState: StateFlow<HidUiState> = hid.state
    val settings: StateFlow<AppSettings> = settingsStore.state

    private val _paired = MutableStateFlow<List<PairedDevice>>(emptyList())
    val paired: StateFlow<List<PairedDevice>> = _paired.asStateFlow()

    private val _skipped = MutableStateFlow(0)
    val skippedChars: StateFlow<Int> = _skipped.asStateFlow()

    private val keyQueue = Channel<KeyStroke>(Channel.UNLIMITED)
    private var density = 1f
    private var engine = TouchpadEngine(settingsStore.state.value.toConfig(density))

    init {
        viewModelScope.launch {
            for (stroke in keyQueue) {
                hid.tapKey(stroke.modifiers, stroke.usage)
                delay(KEY_DELAY_MS)
            }
        }
    }

    private fun rebuildEngine() {
        engine = TouchpadEngine(settingsStore.state.value.toConfig(density))
    }

    fun setDensity(value: Float) {
        if (value > 0f && value != density) {
            density = value
            rebuildEngine()
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settingsStore.update(transform)
        rebuildEngine()
    }

    fun startHid() {
        hid.start()
        refreshPaired()
    }

    fun refreshPaired() {
        _paired.value = hid.pairedDevices()
    }

    fun connect(address: String) {
        hid.connect(address)
    }

    fun disconnect() {
        hid.disconnect()
    }

    fun onTouch(points: List<TouchPoint>, timeMs: Long) {
        for (action in engine.onFrame(points, timeMs)) {
            when (action) {
                is PointerAction.Move -> hid.sendMouse(action.dx, action.dy, 0, 0)
                is PointerAction.Scroll -> hid.sendMouse(0, 0, action.vertical, action.horizontal)
                is PointerAction.ButtonDown -> hid.setButton(action.button.mask, true)
                is PointerAction.ButtonUp -> hid.setButton(action.button.mask, false)
                is PointerAction.Click -> hid.click(action.button.mask)
            }
        }
    }

    fun buttonDown(button: MouseButton) {
        hid.setButton(button.mask, true)
    }

    fun buttonUp(button: MouseButton) {
        hid.setButton(button.mask, false)
    }

    fun sendAction(action: KeyAction) {
        if (action.consumer) {
            hid.sendConsumer(action.usage)
        } else {
            keyQueue.trySend(KeyStroke(action.modifiers, action.usage))
        }
    }

    /** Sends the difference between the previous and the new text field content as key strokes. */
    fun liveEdit(old: String, new: String) {
        val plan = TextTyper.diff(old, new)
        if (plan.skipped > 0) {
            _skipped.update { it + plan.skipped }
        }
        for (stroke in plan.strokes) {
            keyQueue.trySend(stroke)
        }
    }

    fun clearSkipped() {
        _skipped.value = 0
    }

    override fun onCleared() {
        keyQueue.close()
        hid.stop()
        super.onCleared()
    }

    private companion object {
        const val KEY_DELAY_MS = 10L
    }
}
