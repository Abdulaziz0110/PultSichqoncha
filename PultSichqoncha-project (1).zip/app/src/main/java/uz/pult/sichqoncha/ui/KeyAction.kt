package uz.pult.sichqoncha.ui

import androidx.annotation.StringRes

/** A button that sends one key combination (or one media key when [consumer] is true). */
data class KeyAction(
    @StringRes val label: Int,
    val modifiers: Int,
    val usage: Int,
    val consumer: Boolean = false
)
