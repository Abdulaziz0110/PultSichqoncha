package uz.pult.sichqoncha.hid

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import uz.pult.engine.HidDescriptor
import uz.pult.engine.HidReports

enum class HidStatus {
    UNSUPPORTED,
    NO_PERMISSION,
    BLUETOOTH_OFF,
    STOPPED,
    PREPARING,
    READY,
    CONNECTING,
    CONNECTED
}

data class HidUiState(
    val status: HidStatus = HidStatus.STOPPED,
    val deviceName: String? = null
)

data class PairedDevice(val name: String, val address: String)

/**
 * Makes the phone behave as a Bluetooth HID device (mouse + keyboard + media keys)
 * using the platform BluetoothHidDevice profile (API 28+).
 */
@SuppressLint("MissingPermission")
class HidController(context: Context) {
    private val appContext: Context = context.applicationContext
    private val adapter: BluetoothAdapter? =
        appContext.getSystemService(BluetoothManager::class.java)?.adapter
    private val executor = ContextCompat.getMainExecutor(appContext)

    private val _state = MutableStateFlow(
        HidUiState(status = if (adapter == null) HidStatus.UNSUPPORTED else HidStatus.STOPPED)
    )
    val state: StateFlow<HidUiState> = _state.asStateFlow()

    private var hidDevice: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var registered = false
    private var starting = false
    private var buttons = 0

    private fun hasPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return true
        }
        return ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun setStatus(status: HidStatus, deviceName: String? = null) {
        _state.update { it.copy(status = status, deviceName = deviceName) }
    }

    private fun labelOf(device: BluetoothDevice): String = try {
        device.name ?: device.address
    } catch (e: SecurityException) {
        Log.w(TAG, "Bluetooth permission missing while reading device name", e)
        device.address
    }

    private val serviceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile != BluetoothProfile.HID_DEVICE) {
                return
            }
            starting = false
            val device = proxy as? BluetoothHidDevice
            if (device == null) {
                setStatus(HidStatus.UNSUPPORTED)
                return
            }
            hidDevice = device
            registerApp()
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile != BluetoothProfile.HID_DEVICE) {
                return
            }
            hidDevice = null
            host = null
            registered = false
            starting = false
            setStatus(HidStatus.STOPPED)
        }
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidController.registered = registered
            if (!registered) {
                host = null
                setStatus(HidStatus.STOPPED)
                return
            }
            val connected = try {
                pluggedDevice ?: hidDevice?.connectedDevices?.firstOrNull()
            } catch (e: SecurityException) {
                Log.w(TAG, "Cannot read connected devices", e)
                null
            }
            if (connected != null) {
                host = connected
                setStatus(HidStatus.CONNECTED, labelOf(connected))
            } else {
                host = null
                setStatus(HidStatus.READY)
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            if (device == null) {
                return
            }
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    buttons = 0
                    setStatus(HidStatus.CONNECTED, labelOf(device))
                }
                BluetoothProfile.STATE_CONNECTING -> {
                    setStatus(HidStatus.CONNECTING, labelOf(device))
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (host == null || host?.address == device.address) {
                        host = null
                        buttons = 0
                        setStatus(if (registered) HidStatus.READY else HidStatus.STOPPED)
                    }
                }
                else -> Unit
            }
        }
    }

    /** Starts the HID profile. Safe to call repeatedly. */
    fun start() {
        val bt = adapter
        if (bt == null) {
            setStatus(HidStatus.UNSUPPORTED)
            return
        }
        if (!hasPermission()) {
            setStatus(HidStatus.NO_PERMISSION)
            return
        }
        if (!bt.isEnabled) {
            setStatus(HidStatus.BLUETOOTH_OFF)
            return
        }
        if (hidDevice != null) {
            if (!registered) {
                registerApp()
            }
            return
        }
        if (starting) {
            return
        }
        starting = true
        setStatus(HidStatus.PREPARING)
        try {
            val accepted = bt.getProfileProxy(appContext, serviceListener, BluetoothProfile.HID_DEVICE)
            if (!accepted) {
                starting = false
                setStatus(HidStatus.UNSUPPORTED)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Bluetooth permission denied", e)
            starting = false
            setStatus(HidStatus.NO_PERMISSION)
        }
    }

    private fun registerApp() {
        val device = hidDevice ?: return
        val sdp = BluetoothHidDeviceAppSdpSettings(
            APP_NAME,
            APP_DESCRIPTION,
            APP_PROVIDER,
            BluetoothHidDevice.SUBCLASS1_COMBO,
            HidDescriptor.bytes()
        )
        val accepted = try {
            device.registerApp(sdp, null, null, executor, callback)
        } catch (e: SecurityException) {
            Log.w(TAG, "registerApp denied", e)
            setStatus(HidStatus.NO_PERMISSION)
            return
        }
        if (!accepted && !registered) {
            setStatus(HidStatus.UNSUPPORTED)
        }
    }

    fun pairedDevices(): List<PairedDevice> {
        val bt = adapter ?: return emptyList()
        if (!hasPermission()) {
            return emptyList()
        }
        return try {
            bt.bondedDevices.orEmpty()
                .map { PairedDevice(labelOf(it), it.address) }
                .sortedBy { it.name.lowercase() }
        } catch (e: SecurityException) {
            Log.w(TAG, "Cannot list paired devices", e)
            emptyList()
        }
    }

    fun connect(address: String): Boolean {
        val device = hidDevice ?: return false
        val bt = adapter ?: return false
        return try {
            val target = bt.getRemoteDevice(address)
            val current = host
            if (current != null && current.address != address) {
                device.disconnect(current)
            }
            setStatus(HidStatus.CONNECTING, labelOf(target))
            val accepted = device.connect(target)
            if (!accepted) {
                setStatus(if (registered) HidStatus.READY else HidStatus.STOPPED)
            }
            accepted
        } catch (e: SecurityException) {
            Log.w(TAG, "connect denied", e)
            setStatus(HidStatus.NO_PERMISSION)
            false
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Invalid Bluetooth address", e)
            setStatus(if (registered) HidStatus.READY else HidStatus.STOPPED)
            false
        }
    }

    fun disconnect() {
        val device = hidDevice ?: return
        val current = host ?: return
        try {
            device.disconnect(current)
        } catch (e: SecurityException) {
            Log.w(TAG, "disconnect denied", e)
        }
    }

    /** Releases the HID profile. The phone stops being visible as a mouse/keyboard. */
    fun stop() {
        val device = hidDevice
        val bt = adapter
        try {
            if (device != null) {
                if (registered) {
                    device.unregisterApp()
                }
                bt?.closeProfileProxy(BluetoothProfile.HID_DEVICE, device)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "stop denied", e)
        }
        hidDevice = null
        host = null
        registered = false
        starting = false
        buttons = 0
        setStatus(if (adapter == null) HidStatus.UNSUPPORTED else HidStatus.STOPPED)
    }

    private fun send(reportId: Int, data: ByteArray): Boolean {
        val device = hidDevice ?: return false
        val target = host ?: return false
        return try {
            device.sendReport(target, reportId, data)
        } catch (e: SecurityException) {
            Log.w(TAG, "sendReport denied", e)
            false
        }
    }

    fun sendMouse(dx: Int, dy: Int, wheel: Int, pan: Int) {
        for (report in HidReports.mouseReports(buttons, dx, dy, wheel, pan)) {
            send(HidDescriptor.ID_MOUSE, report)
        }
    }

    fun setButton(mask: Int, down: Boolean) {
        buttons = if (down) buttons or mask else buttons and mask.inv()
        send(HidDescriptor.ID_MOUSE, HidReports.mouse(buttons, 0, 0, 0, 0))
    }

    fun click(mask: Int) {
        setButton(mask, true)
        setButton(mask, false)
    }

    fun tapKey(modifiers: Int, usage: Int) {
        send(HidDescriptor.ID_KEYBOARD, HidReports.keyboard(modifiers, intArrayOf(usage)))
        send(HidDescriptor.ID_KEYBOARD, HidReports.keyboard(0, IntArray(0)))
    }

    fun sendConsumer(usage: Int) {
        send(HidDescriptor.ID_CONSUMER, HidReports.consumer(usage))
        send(HidDescriptor.ID_CONSUMER, HidReports.consumer(0))
    }

    private companion object {
        const val TAG = "HidController"
        const val APP_NAME = "Pult Sichqoncha"
        const val APP_DESCRIPTION = "Phone mouse and keyboard"
        const val APP_PROVIDER = "Pult"
    }
}
