package uz.pult.sichqoncha.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.util.Log

fun startActivitySafely(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Log.w("Intents", "No activity for $intent", e)
    } catch (e: SecurityException) {
        Log.w("Intents", "Not allowed to start $intent", e)
    }
}
