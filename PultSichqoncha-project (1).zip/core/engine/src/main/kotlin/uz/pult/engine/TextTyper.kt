package uz.pult.engine

data class TypePlan(val strokes: List<KeyStroke>, val skipped: Int)

/** Turns text or text edits into key strokes. Characters outside US ASCII are skipped and counted. */
object TextTyper {
    fun plan(text: String): TypePlan {
        val strokes = ArrayList<KeyStroke>(text.length)
        var skipped = 0
        for (c in text) {
            val stroke = KeyMap.forChar(c)
            if (stroke == null) {
                skipped++
            } else {
                strokes.add(stroke)
            }
        }
        return TypePlan(strokes, skipped)
    }

    /** Key strokes needed to turn [old] into [new]: backspaces for the changed tail, then the new characters. */
    fun diff(old: String, new: String): TypePlan {
        var prefix = 0
        val limit = minOf(old.length, new.length)
        while (prefix < limit && old[prefix] == new[prefix]) {
            prefix++
        }
        val strokes = ArrayList<KeyStroke>()
        for (i in 0 until (old.length - prefix)) {
            strokes.add(KeyStroke(0, Keys.BACKSPACE))
        }
        val added = plan(new.substring(prefix))
        strokes.addAll(added.strokes)
        return TypePlan(strokes, added.skipped)
    }
}
