package uz.pult.engine

data class KeyStroke(val modifiers: Int, val usage: Int)

object Modifiers {
    const val CTRL = 0x01
    const val SHIFT = 0x02
    const val ALT = 0x04
    const val GUI = 0x08
}

/** Keyboard usage codes (HID usage page 0x07). */
object Keys {
    const val A = 0x04
    const val B = 0x05
    const val C = 0x06
    const val L = 0x0F
    const val S = 0x16
    const val V = 0x19
    const val W = 0x1A
    const val X = 0x1B
    const val Z = 0x1D
    const val ENTER = 0x28
    const val ESCAPE = 0x29
    const val BACKSPACE = 0x2A
    const val TAB = 0x2B
    const val SPACE = 0x2C
    const val F5 = 0x3E
    const val HOME = 0x4A
    const val PAGE_UP = 0x4B
    const val DELETE = 0x4C
    const val END = 0x4D
    const val PAGE_DOWN = 0x4E
    const val RIGHT = 0x4F
    const val LEFT = 0x50
    const val DOWN = 0x51
    const val UP = 0x52
    const val NONE = 0x00
}

/** Consumer control usage codes (HID usage page 0x0C). */
object ConsumerKeys {
    const val PLAY_PAUSE = 0xCD
    const val NEXT_TRACK = 0xB5
    const val PREV_TRACK = 0xB6
    const val MUTE = 0xE2
    const val VOLUME_UP = 0xE9
    const val VOLUME_DOWN = 0xEA
}

/** Maps printable US-layout ASCII characters to HID key strokes. */
object KeyMap {
    private val table: Map<Char, KeyStroke> = buildMap {
        for (c in 'a'..'z') {
            put(c, KeyStroke(0, Keys.A + (c - 'a')))
            put(c.uppercaseChar(), KeyStroke(Modifiers.SHIFT, Keys.A + (c - 'a')))
        }
        for (c in '1'..'9') {
            put(c, KeyStroke(0, 0x1E + (c - '1')))
        }
        put('0', KeyStroke(0, 0x27))
        val shiftedDigits = "!@#\$%^&*()"
        for ((index, c) in shiftedDigits.withIndex()) {
            val usage = if (index == 9) 0x27 else 0x1E + index
            put(c, KeyStroke(Modifiers.SHIFT, usage))
        }
        put(' ', KeyStroke(0, Keys.SPACE))
        put('\n', KeyStroke(0, Keys.ENTER))
        put('\t', KeyStroke(0, Keys.TAB))
        val pairs = listOf(
            Triple('-', '_', 0x2D),
            Triple('=', '+', 0x2E),
            Triple('[', '{', 0x2F),
            Triple(']', '}', 0x30),
            Triple('\\', '|', 0x31),
            Triple(';', ':', 0x33),
            Triple('\'', '"', 0x34),
            Triple('`', '~', 0x35),
            Triple(',', '<', 0x36),
            Triple('.', '>', 0x37),
            Triple('/', '?', 0x38)
        )
        for ((plain, shifted, usage) in pairs) {
            put(plain, KeyStroke(0, usage))
            put(shifted, KeyStroke(Modifiers.SHIFT, usage))
        }
    }

    fun forChar(c: Char): KeyStroke? = table[c]
}
