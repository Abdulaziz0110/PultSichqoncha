package uz.pult.engine

/**
 * Combined HID report descriptor.
 * Report id 1: mouse (3 buttons, X, Y, wheel, horizontal pan) - 5 bytes.
 * Report id 2: keyboard (modifiers, reserved, 6 keys) - 8 bytes.
 * Report id 3: consumer control (one 16-bit usage) - 2 bytes.
 */
object HidDescriptor {
    const val ID_MOUSE = 1
    const val ID_KEYBOARD = 2
    const val ID_CONSUMER = 3

    private val items: IntArray = intArrayOf(
        // ---- Mouse ----
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x02,             // Usage (Mouse)
        0xA1, 0x01,             // Collection (Application)
        0x85, ID_MOUSE,         //   Report ID
        0x09, 0x01,             //   Usage (Pointer)
        0xA1, 0x00,             //   Collection (Physical)
        0x05, 0x09,             //     Usage Page (Button)
        0x19, 0x01,             //     Usage Minimum (1)
        0x29, 0x03,             //     Usage Maximum (3)
        0x15, 0x00,             //     Logical Minimum (0)
        0x25, 0x01,             //     Logical Maximum (1)
        0x95, 0x03,             //     Report Count (3)
        0x75, 0x01,             //     Report Size (1)
        0x81, 0x02,             //     Input (Data, Variable, Absolute)
        0x95, 0x01,             //     Report Count (1)
        0x75, 0x05,             //     Report Size (5)
        0x81, 0x03,             //     Input (Constant)
        0x05, 0x01,             //     Usage Page (Generic Desktop)
        0x09, 0x30,             //     Usage (X)
        0x09, 0x31,             //     Usage (Y)
        0x09, 0x38,             //     Usage (Wheel)
        0x15, 0x81,             //     Logical Minimum (-127)
        0x25, 0x7F,             //     Logical Maximum (127)
        0x75, 0x08,             //     Report Size (8)
        0x95, 0x03,             //     Report Count (3)
        0x81, 0x06,             //     Input (Data, Variable, Relative)
        0x05, 0x0C,             //     Usage Page (Consumer)
        0x0A, 0x38, 0x02,       //     Usage (AC Pan)
        0x95, 0x01,             //     Report Count (1)
        0x81, 0x06,             //     Input (Data, Variable, Relative)
        0xC0,                   //   End Collection
        0xC0,                   // End Collection
        // ---- Keyboard ----
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x06,             // Usage (Keyboard)
        0xA1, 0x01,             // Collection (Application)
        0x85, ID_KEYBOARD,      //   Report ID
        0x05, 0x07,             //   Usage Page (Keyboard)
        0x19, 0xE0,             //   Usage Minimum (Left Control)
        0x29, 0xE7,             //   Usage Maximum (Right GUI)
        0x15, 0x00,             //   Logical Minimum (0)
        0x25, 0x01,             //   Logical Maximum (1)
        0x75, 0x01,             //   Report Size (1)
        0x95, 0x08,             //   Report Count (8)
        0x81, 0x02,             //   Input (Data, Variable, Absolute)
        0x95, 0x01,             //   Report Count (1)
        0x75, 0x08,             //   Report Size (8)
        0x81, 0x01,             //   Input (Constant)
        0x95, 0x06,             //   Report Count (6)
        0x75, 0x08,             //   Report Size (8)
        0x15, 0x00,             //   Logical Minimum (0)
        0x25, 0x65,             //   Logical Maximum (101)
        0x05, 0x07,             //   Usage Page (Keyboard)
        0x19, 0x00,             //   Usage Minimum (0)
        0x29, 0x65,             //   Usage Maximum (101)
        0x81, 0x00,             //   Input (Data, Array)
        0xC0,                   // End Collection
        // ---- Consumer control ----
        0x05, 0x0C,             // Usage Page (Consumer)
        0x09, 0x01,             // Usage (Consumer Control)
        0xA1, 0x01,             // Collection (Application)
        0x85, ID_CONSUMER,      //   Report ID
        0x15, 0x00,             //   Logical Minimum (0)
        0x26, 0xFF, 0x03,       //   Logical Maximum (1023)
        0x19, 0x00,             //   Usage Minimum (0)
        0x2A, 0xFF, 0x03,       //   Usage Maximum (1023)
        0x75, 0x10,             //   Report Size (16)
        0x95, 0x01,             //   Report Count (1)
        0x81, 0x00,             //   Input (Data, Array)
        0xC0                    // End Collection
    )

    fun bytes(): ByteArray = ByteArray(items.size) { index -> items[index].toByte() }
}
