package uz.pult.engine

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

data class TouchPoint(val id: Int, val x: Float, val y: Float)

enum class MouseButton(val mask: Int) {
    LEFT(1),
    RIGHT(2),
    MIDDLE(4)
}

sealed interface PointerAction {
    data class Move(val dx: Int, val dy: Int) : PointerAction
    data class Scroll(val vertical: Int, val horizontal: Int) : PointerAction
    data class ButtonDown(val button: MouseButton) : PointerAction
    data class ButtonUp(val button: MouseButton) : PointerAction
    data class Click(val button: MouseButton) : PointerAction
}

data class TouchpadConfig(
    val sensitivity: Float = 1.5f,
    val acceleration: Boolean = true,
    val scrollSpeed: Float = 1.0f,
    val naturalScroll: Boolean = false,
    val tapToClick: Boolean = true,
    val density: Float = 1f,
    val tapTimeoutMs: Long = 250L,
    val dragWindowMs: Long = 300L,
    val tapSlopDp: Float = 10f,
    val scrollDpPerNotch: Float = 14f
)

/**
 * Turns touch frames into mouse actions.
 * Call [onFrame] on every touch event with the pointers that are currently pressed
 * (an empty list means that all fingers are lifted).
 */
class TouchpadEngine(private val config: TouchpadConfig = TouchpadConfig()) {
    private val density: Float = if (config.density > 0f) config.density else 1f

    private var prevCount = 0
    private var lastX = 0f
    private var lastY = 0f
    private var startTime = 0L
    private var moved = 0f
    private var maxPointers = 0
    private var suppress = false
    private var dragging = false
    private var hasTap = false
    private var lastTapTime = 0L
    private var remX = 0f
    private var remY = 0f
    private var scrollRemX = 0f
    private var scrollRemY = 0f

    fun reset() {
        prevCount = 0
        maxPointers = 0
        suppress = false
        dragging = false
        hasTap = false
        clearRemainders()
    }

    fun onFrame(points: List<TouchPoint>, timeMs: Long): List<PointerAction> {
        val out = ArrayList<PointerAction>(2)
        val n = points.size
        if (n == 0) {
            if (prevCount > 0) {
                finish(timeMs, out)
            }
            return out
        }
        var sumX = 0f
        var sumY = 0f
        for (p in points) {
            sumX += p.x
            sumY += p.y
        }
        val cx = sumX / n
        val cy = sumY / n

        if (prevCount == 0) {
            begin(n, cx, cy, timeMs, out)
            return out
        }
        if (n != prevCount) {
            if (n < prevCount) {
                suppress = true
            }
            prevCount = n
            if (n > maxPointers) {
                maxPointers = n
            }
            lastX = cx
            lastY = cy
            scrollRemX = 0f
            scrollRemY = 0f
            return out
        }

        val dx = cx - lastX
        val dy = cy - lastY
        lastX = cx
        lastY = cy
        moved += hypot(dx, dy)
        if (suppress) {
            return out
        }
        when (n) {
            1 -> moveCursor(dx, dy, out)
            2 -> scroll(dx, dy, out)
            else -> Unit
        }
        return out
    }

    private fun begin(n: Int, cx: Float, cy: Float, timeMs: Long, out: MutableList<PointerAction>) {
        prevCount = n
        maxPointers = n
        lastX = cx
        lastY = cy
        startTime = timeMs
        moved = 0f
        suppress = false
        clearRemainders()
        if (config.tapToClick && n == 1 && hasTap && timeMs - lastTapTime <= config.dragWindowMs) {
            dragging = true
            hasTap = false
            out.add(PointerAction.ButtonDown(MouseButton.LEFT))
        }
    }

    private fun finish(timeMs: Long, out: MutableList<PointerAction>) {
        val duration = timeMs - startTime
        val pointers = maxPointers
        prevCount = 0
        maxPointers = 0
        suppress = false
        clearRemainders()
        if (dragging) {
            dragging = false
            hasTap = false
            out.add(PointerAction.ButtonUp(MouseButton.LEFT))
            return
        }
        val isTap = config.tapToClick && moved <= config.tapSlopDp * density && duration <= config.tapTimeoutMs
        if (!isTap) {
            hasTap = false
            return
        }
        when (pointers) {
            1 -> {
                out.add(PointerAction.Click(MouseButton.LEFT))
                hasTap = true
                lastTapTime = timeMs
            }
            2 -> {
                out.add(PointerAction.Click(MouseButton.RIGHT))
                hasTap = false
            }
            3 -> {
                out.add(PointerAction.Click(MouseButton.MIDDLE))
                hasTap = false
            }
            else -> hasTap = false
        }
    }

    private fun moveCursor(dx: Float, dy: Float, out: MutableList<PointerAction>) {
        var factor = config.sensitivity * BASE_PX_PER_DP
        if (config.acceleration) {
            val speedDp = hypot(dx, dy) / density
            factor *= 1f + min(speedDp, MAX_ACCEL_SPEED_DP) * ACCEL_GAIN
        }
        remX += dx / density * factor
        remY += dy / density * factor
        val ix = remX.toInt()
        val iy = remY.toInt()
        remX -= ix
        remY -= iy
        if (ix != 0 || iy != 0) {
            out.add(PointerAction.Move(ix, iy))
        }
    }

    private fun scroll(dx: Float, dy: Float, out: MutableList<PointerAction>) {
        val divisor = config.scrollDpPerNotch * density
        if (abs(dy) >= abs(dx)) {
            val direction = if (config.naturalScroll) 1f else -1f
            scrollRemY += direction * dy * config.scrollSpeed / divisor
        } else {
            val direction = if (config.naturalScroll) -1f else 1f
            scrollRemX += direction * dx * config.scrollSpeed / divisor
        }
        val iy = scrollRemY.toInt()
        val ix = scrollRemX.toInt()
        scrollRemY -= iy
        scrollRemX -= ix
        if (iy != 0 || ix != 0) {
            out.add(PointerAction.Scroll(iy, ix))
        }
    }

    private fun clearRemainders() {
        remX = 0f
        remY = 0f
        scrollRemX = 0f
        scrollRemY = 0f
    }

    private companion object {
        const val BASE_PX_PER_DP = 2f
        const val MAX_ACCEL_SPEED_DP = 25f
        const val ACCEL_GAIN = 0.08f
    }
}
