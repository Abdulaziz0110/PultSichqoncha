package uz.pult.engine

/** Builds HID input reports (without the report id byte). */
object HidReports {
    const val MOUSE_REPORT_SIZE = 5
    const val KEYBOARD_REPORT_SIZE = 8
    const val CONSUMER_REPORT_SIZE = 2
    const val MAX_STEP = 127
    const val MAX_KEYS = 6

    private fun clampStep(value: Int): Int = value.coerceIn(-MAX_STEP, MAX_STEP)

    fun mouse(buttons: Int, dx: Int, dy: Int, wheel: Int, pan: Int): ByteArray = byteArrayOf(
        (buttons and 0x07).toByte(),
        clampStep(dx).toByte(),
        clampStep(dy).toByte(),
        clampStep(wheel).toByte(),
        clampStep(pan).toByte()
    )

    /** Splits a large movement into several reports, each within the -127..127 range. */
    fun mouseReports(buttons: Int, dx: Int, dy: Int, wheel: Int, pan: Int): List<ByteArray> {
        val reports = ArrayList<ByteArray>()
        var restX = dx
        var restY = dy
        var restWheel = wheel
        var restPan = pan
        while (restX != 0 || restY != 0 || restWheel != 0 || restPan != 0) {
            val stepX = clampStep(restX)
            val stepY = clampStep(restY)
            val stepWheel = clampStep(restWheel)
            val stepPan = clampStep(restPan)
            reports.add(mouse(buttons, stepX, stepY, stepWheel, stepPan))
            restX -= stepX
            restY -= stepY
            restWheel -= stepWheel
            restPan -= stepPan
        }
        return reports
    }

    fun keyboard(modifiers: Int, keys: IntArray): ByteArray {
        val report = ByteArray(KEYBOARD_REPORT_SIZE)
        report[0] = (modifiers and 0xFF).toByte()
        report[1] = 0
        val count = minOf(keys.size, MAX_KEYS)
        for (i in 0 until count) {
            report[2 + i] = (keys[i] and 0xFF).toByte()
        }
        return report
    }

    fun consumer(usage: Int): ByteArray = byteArrayOf(
        (usage and 0xFF).toByte(),
        ((usage shr 8) and 0xFF).toByte()
    )
}
