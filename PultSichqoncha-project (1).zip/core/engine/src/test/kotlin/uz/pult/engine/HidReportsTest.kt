package uz.pult.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class HidReportsTest {
    @Test
    fun mouseReportLayout() {
        val r = HidReports.mouse(0x03, 5, -5, 1, -1)
        assertEquals(HidReports.MOUSE_REPORT_SIZE, r.size)
        assertArrayEquals(byteArrayOf(3, 5, -5, 1, -1), r)
    }

    @Test
    fun mouseValuesAreClamped() {
        val r = HidReports.mouse(0xFF, 500, -500, 200, -200)
        assertArrayEquals(byteArrayOf(7, 127, -127, 127, -127), r)
    }

    @Test
    fun largeMovementIsSplit() {
        val reports = HidReports.mouseReports(0, 300, -10, 0, 0)
        assertEquals(3, reports.size)
        assertEquals(127.toByte(), reports[0][1])
        assertEquals(127.toByte(), reports[1][1])
        assertEquals(46.toByte(), reports[2][1])
        var sumX = 0
        var sumY = 0
        for (r in reports) {
            sumX += r[1].toInt()
            sumY += r[2].toInt()
        }
        assertEquals(300, sumX)
        assertEquals(-10, sumY)
    }

    @Test
    fun zeroMovementProducesNoReports() {
        assertEquals(0, HidReports.mouseReports(1, 0, 0, 0, 0).size)
    }

    @Test
    fun buttonsAreKeptInEverySplitReport() {
        val reports = HidReports.mouseReports(1, 200, 0, 0, 0)
        for (r in reports) {
            assertEquals(1.toByte(), r[0])
        }
    }

    @Test
    fun keyboardReportLayout() {
        val r = HidReports.keyboard(Modifiers.CTRL or Modifiers.SHIFT, intArrayOf(Keys.C))
        assertEquals(HidReports.KEYBOARD_REPORT_SIZE, r.size)
        assertEquals(3.toByte(), r[0])
        assertEquals(0.toByte(), r[1])
        assertEquals(Keys.C.toByte(), r[2])
        assertEquals(0.toByte(), r[3])
    }

    @Test
    fun keyboardReportIgnoresMoreThanSixKeys() {
        val r = HidReports.keyboard(0, intArrayOf(4, 5, 6, 7, 8, 9, 10, 11))
        assertEquals(8, r.size)
        assertEquals(9.toByte(), r[7])
    }

    @Test
    fun releaseReportIsAllZero() {
        assertArrayEquals(ByteArray(8), HidReports.keyboard(0, IntArray(0)))
    }

    @Test
    fun consumerReportIsLittleEndian() {
        assertArrayEquals(byteArrayOf(0xE9.toByte(), 0), HidReports.consumer(ConsumerKeys.VOLUME_UP))
        assertArrayEquals(byteArrayOf(0x34, 0x02), HidReports.consumer(0x0234))
        assertArrayEquals(byteArrayOf(0, 0), HidReports.consumer(0))
    }
}
