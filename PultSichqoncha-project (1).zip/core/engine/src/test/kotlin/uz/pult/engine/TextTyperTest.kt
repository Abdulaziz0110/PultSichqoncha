package uz.pult.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class TextTyperTest {
    @Test
    fun plansSupportedText() {
        val plan = TextTyper.plan("Hi 1")
        assertEquals(4, plan.strokes.size)
        assertEquals(0, plan.skipped)
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x0B), plan.strokes[0])
    }

    @Test
    fun skipsUnsupportedCharacters() {
        val plan = TextTyper.plan("a\u00E9b\u0416")
        assertEquals(2, plan.strokes.size)
        assertEquals(2, plan.skipped)
    }

    @Test
    fun diffAppend() {
        val plan = TextTyper.diff("ab", "abc")
        assertEquals(listOf(KeyStroke(0, 0x06)), plan.strokes)
    }

    @Test
    fun diffDelete() {
        val plan = TextTyper.diff("abc", "ab")
        assertEquals(listOf(KeyStroke(0, Keys.BACKSPACE)), plan.strokes)
    }

    @Test
    fun diffReplaceInMiddle() {
        val plan = TextTyper.diff("abc", "axc")
        assertEquals(
            listOf(
                KeyStroke(0, Keys.BACKSPACE),
                KeyStroke(0, Keys.BACKSPACE),
                KeyStroke(0, 0x1B),
                KeyStroke(0, 0x06)
            ),
            plan.strokes
        )
    }

    @Test
    fun diffNoChange() {
        val plan = TextTyper.diff("same", "same")
        assertEquals(0, plan.strokes.size)
        assertEquals(0, plan.skipped)
    }

    @Test
    fun diffCountsSkippedOnlyForAddedText() {
        val plan = TextTyper.diff("a", "a\u0416")
        assertEquals(0, plan.strokes.size)
        assertEquals(1, plan.skipped)
    }
}
