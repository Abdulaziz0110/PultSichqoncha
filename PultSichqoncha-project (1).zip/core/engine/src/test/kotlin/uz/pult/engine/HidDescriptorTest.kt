package uz.pult.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HidDescriptorTest {
    private class Parsed(val depth: Int, val bitsById: Map<Int, Int>, val ids: List<Int>)

    private fun parse(d: ByteArray): Parsed {
        var i = 0
        var depth = 0
        var reportSize = 0
        var reportCount = 0
        var reportId = 0
        val bits = LinkedHashMap<Int, Int>()
        val ids = ArrayList<Int>()
        while (i < d.size) {
            val prefix = d[i].toInt() and 0xFF
            val sizeCode = prefix and 0x03
            val size = if (sizeCode == 3) 4 else sizeCode
            val type = (prefix shr 2) and 0x03
            val tag = prefix shr 4
            var value = 0
            for (k in 0 until size) {
                value = value or ((d[i + 1 + k].toInt() and 0xFF) shl (8 * k))
            }
            if (type == 0) {
                if (tag == 0xA) depth++
                if (tag == 0xC) depth--
                if (tag == 0x8) bits[reportId] = (bits[reportId] ?: 0) + reportSize * reportCount
            } else if (type == 1) {
                if (tag == 0x7) reportSize = value
                if (tag == 0x9) reportCount = value
                if (tag == 0x8) {
                    reportId = value
                    ids.add(value)
                }
            }
            i += 1 + size
        }
        assertEquals("descriptor items must consume all bytes", d.size, i)
        return Parsed(depth, bits, ids)
    }

    @Test
    fun collectionsAreBalanced() {
        assertEquals(0, parse(HidDescriptor.bytes()).depth)
    }

    @Test
    fun reportIdsAreMouseKeyboardConsumer() {
        assertEquals(listOf(1, 2, 3), parse(HidDescriptor.bytes()).ids)
    }

    @Test
    fun reportSizesMatchBuilders() {
        val parsed = parse(HidDescriptor.bytes())
        assertEquals(HidReports.MOUSE_REPORT_SIZE * 8, parsed.bitsById[HidDescriptor.ID_MOUSE])
        assertEquals(HidReports.KEYBOARD_REPORT_SIZE * 8, parsed.bitsById[HidDescriptor.ID_KEYBOARD])
        assertEquals(HidReports.CONSUMER_REPORT_SIZE * 8, parsed.bitsById[HidDescriptor.ID_CONSUMER])
    }

    @Test
    fun descriptorStartsWithGenericDesktopMouse() {
        val d = HidDescriptor.bytes()
        assertTrue(d.size > 50)
        assertEquals(0x05.toByte(), d[0])
        assertEquals(0x01.toByte(), d[1])
        assertEquals(0x09.toByte(), d[2])
        assertEquals(0x02.toByte(), d[3])
    }
}
