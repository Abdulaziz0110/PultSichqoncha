package uz.pult.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TouchpadEngineTest {
    private fun p(id: Int, x: Float, y: Float) = TouchPoint(id, x, y)

    private fun plain(
        sensitivity: Float = 1f,
        acceleration: Boolean = false,
        natural: Boolean = false,
        tap: Boolean = true
    ) = TouchpadEngine(
        TouchpadConfig(
            sensitivity = sensitivity,
            acceleration = acceleration,
            scrollSpeed = 1f,
            naturalScroll = natural,
            tapToClick = tap,
            density = 1f
        )
    )

    @Test
    fun singleFingerMovesCursor() {
        val e = plain()
        assertTrue(e.onFrame(listOf(p(1, 0f, 0f)), 0L).isEmpty())
        val out = e.onFrame(listOf(p(1, 10f, 0f)), 16L)
        assertEquals(listOf<PointerAction>(PointerAction.Move(20, 0)), out)
    }

    @Test
    fun movementRemainderIsCarried() {
        val e = plain(sensitivity = 0.25f)
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        assertTrue(e.onFrame(listOf(p(1, 1f, 0f)), 16L).isEmpty())
        val out = e.onFrame(listOf(p(1, 2f, 0f)), 32L)
        assertEquals(listOf<PointerAction>(PointerAction.Move(1, 0)), out)
    }

    @Test
    fun negativeMovement() {
        val e = plain()
        e.onFrame(listOf(p(1, 50f, 50f)), 0L)
        val out = e.onFrame(listOf(p(1, 45f, 40f)), 16L)
        assertEquals(listOf<PointerAction>(PointerAction.Move(-10, -20)), out)
    }

    @Test
    fun accelerationMakesFastMovesBigger() {
        val slow = plain(acceleration = true)
        slow.onFrame(listOf(p(1, 0f, 0f)), 0L)
        val out = slow.onFrame(listOf(p(1, 10f, 0f)), 16L)
        val move = out[0] as PointerAction.Move
        assertTrue(move.dx > 20)
    }

    @Test
    fun quickTapIsLeftClick() {
        val e = plain()
        e.onFrame(listOf(p(1, 5f, 5f)), 0L)
        val out = e.onFrame(emptyList(), 100L)
        assertEquals(listOf<PointerAction>(PointerAction.Click(MouseButton.LEFT)), out)
    }

    @Test
    fun longPressIsNotATap() {
        val e = plain()
        e.onFrame(listOf(p(1, 5f, 5f)), 0L)
        assertTrue(e.onFrame(emptyList(), 600L).isEmpty())
    }

    @Test
    fun movedTouchIsNotATap() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        e.onFrame(listOf(p(1, 40f, 0f)), 20L)
        assertTrue(e.onFrame(emptyList(), 80L).isEmpty())
    }

    @Test
    fun tapToClickCanBeDisabled() {
        val e = plain(tap = false)
        e.onFrame(listOf(p(1, 5f, 5f)), 0L)
        assertTrue(e.onFrame(emptyList(), 80L).isEmpty())
    }

    @Test
    fun twoFingerTapIsRightClick() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 0L)
        val out = e.onFrame(emptyList(), 90L)
        assertEquals(listOf<PointerAction>(PointerAction.Click(MouseButton.RIGHT)), out)
    }

    @Test
    fun twoFingerTapWithStaggeredLandingIsRightClick() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 10L)
        val out = e.onFrame(emptyList(), 90L)
        assertEquals(listOf<PointerAction>(PointerAction.Click(MouseButton.RIGHT)), out)
    }

    @Test
    fun threeFingerTapIsMiddleClick() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 30f, 0f), p(3, 60f, 0f)), 0L)
        val out = e.onFrame(emptyList(), 90L)
        assertEquals(listOf<PointerAction>(PointerAction.Click(MouseButton.MIDDLE)), out)
    }

    @Test
    fun twoFingerScrollDownGivesNegativeWheel() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 0L)
        val out = e.onFrame(listOf(p(1, 0f, 28f), p(2, 50f, 28f)), 16L)
        assertEquals(listOf<PointerAction>(PointerAction.Scroll(-2, 0)), out)
    }

    @Test
    fun naturalScrollReversesDirection() {
        val e = plain(natural = true)
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 0L)
        val out = e.onFrame(listOf(p(1, 0f, 28f), p(2, 50f, 28f)), 16L)
        assertEquals(listOf<PointerAction>(PointerAction.Scroll(2, 0)), out)
    }

    @Test
    fun horizontalScroll() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 0L)
        val out = e.onFrame(listOf(p(1, 14f, 0f), p(2, 64f, 0f)), 16L)
        assertEquals(listOf<PointerAction>(PointerAction.Scroll(0, 1)), out)
    }

    @Test
    fun scrollDoesNotMoveCursorOrClick() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 0L)
        e.onFrame(listOf(p(1, 0f, 28f), p(2, 50f, 28f)), 16L)
        val out = e.onFrame(emptyList(), 100L)
        assertTrue(out.isEmpty())
    }

    @Test
    fun liftingOneFingerAfterScrollDoesNotMoveCursor() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f), p(2, 50f, 0f)), 0L)
        assertTrue(e.onFrame(listOf(p(1, 0f, 0f)), 10L).isEmpty())
        assertTrue(e.onFrame(listOf(p(1, 80f, 80f)), 20L).isEmpty())
    }

    @Test
    fun tapThenTouchAndDragHoldsLeftButton() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        assertEquals(listOf<PointerAction>(PointerAction.Click(MouseButton.LEFT)), e.onFrame(emptyList(), 80L))
        val down = e.onFrame(listOf(p(1, 0f, 0f)), 200L)
        assertEquals(listOf<PointerAction>(PointerAction.ButtonDown(MouseButton.LEFT)), down)
        val move = e.onFrame(listOf(p(1, 10f, 0f)), 216L)
        assertEquals(listOf<PointerAction>(PointerAction.Move(20, 0)), move)
        val up = e.onFrame(emptyList(), 400L)
        assertEquals(listOf<PointerAction>(PointerAction.ButtonUp(MouseButton.LEFT)), up)
    }

    @Test
    fun slowSecondTouchIsNotADrag() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        e.onFrame(emptyList(), 80L)
        val down = e.onFrame(listOf(p(1, 0f, 0f)), 1000L)
        assertTrue(down.isEmpty())
    }

    @Test
    fun doubleTapProducesTwoClicksWithDragReleaseInBetween() {
        val e = plain()
        val actions = ArrayList<PointerAction>()
        actions.addAll(e.onFrame(listOf(p(1, 0f, 0f)), 0L))
        actions.addAll(e.onFrame(emptyList(), 60L))
        actions.addAll(e.onFrame(listOf(p(1, 0f, 0f)), 150L))
        actions.addAll(e.onFrame(emptyList(), 210L))
        assertEquals(
            listOf<PointerAction>(
                PointerAction.Click(MouseButton.LEFT),
                PointerAction.ButtonDown(MouseButton.LEFT),
                PointerAction.ButtonUp(MouseButton.LEFT)
            ),
            actions
        )
    }

    @Test
    fun emptyFramesWithoutTouchDoNothing() {
        val e = plain()
        assertTrue(e.onFrame(emptyList(), 0L).isEmpty())
        assertTrue(e.onFrame(emptyList(), 10L).isEmpty())
    }

    @Test
    fun densityScalesMovement() {
        val e = TouchpadEngine(
            TouchpadConfig(sensitivity = 1f, acceleration = false, density = 2f)
        )
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        val out = e.onFrame(listOf(p(1, 10f, 0f)), 16L)
        assertEquals(listOf<PointerAction>(PointerAction.Move(10, 0)), out)
    }

    @Test
    fun resetClearsGestureState() {
        val e = plain()
        e.onFrame(listOf(p(1, 0f, 0f)), 0L)
        e.reset()
        assertTrue(e.onFrame(emptyList(), 50L).isEmpty())
    }
}
