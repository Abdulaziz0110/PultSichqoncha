package uz.pult.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class KeyMapTest {
    @Test
    fun lowercaseLetters() {
        assertEquals(KeyStroke(0, 0x04), KeyMap.forChar('a'))
        assertEquals(KeyStroke(0, 0x1D), KeyMap.forChar('z'))
    }

    @Test
    fun uppercaseUsesShift() {
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x04), KeyMap.forChar('A'))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x1D), KeyMap.forChar('Z'))
    }

    @Test
    fun digitsAndShiftedDigits() {
        assertEquals(KeyStroke(0, 0x1E), KeyMap.forChar('1'))
        assertEquals(KeyStroke(0, 0x26), KeyMap.forChar('9'))
        assertEquals(KeyStroke(0, 0x27), KeyMap.forChar('0'))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x1E), KeyMap.forChar('!'))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x1F), KeyMap.forChar('@'))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x27), KeyMap.forChar(')'))
    }

    @Test
    fun whitespaceAndPunctuation() {
        assertEquals(KeyStroke(0, Keys.SPACE), KeyMap.forChar(' '))
        assertEquals(KeyStroke(0, Keys.ENTER), KeyMap.forChar('\n'))
        assertEquals(KeyStroke(0, Keys.TAB), KeyMap.forChar('\t'))
        assertEquals(KeyStroke(0, 0x38), KeyMap.forChar('/'))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x38), KeyMap.forChar('?'))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x33), KeyMap.forChar(':'))
        assertEquals(KeyStroke(0, 0x34), KeyMap.forChar('\''))
        assertEquals(KeyStroke(Modifiers.SHIFT, 0x34), KeyMap.forChar('"'))
    }

    @Test
    fun everyPrintableAsciiIsMapped() {
        for (code in 0x20..0x7E) {
            assertNotNull("char code $code", KeyMap.forChar(code.toChar()))
        }
    }

    @Test
    fun nonAsciiIsNotMapped() {
        assertNull(KeyMap.forChar('\u00E9'))
        assertNull(KeyMap.forChar('\u0416'))
    }

    @Test
    fun specialConstantsAreConsistent() {
        assertEquals(0x04 + 22, Keys.W)
        assertEquals(0x04 + 11, Keys.L)
        assertEquals(0x04 + 1, Keys.B)
        assertEquals(0x04 + 2, Keys.C)
        assertEquals(0x04 + 21, Keys.V)
        assertEquals(0x04 + 23, Keys.X)
        assertEquals(0x04 + 25, Keys.Z)
        assertEquals(0x04 + 18, Keys.S)
    }
}
